package com.klef.jfsd.springboot.SpringBootHelloWorldApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sdp3AmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
