package com.klef.jfsd.springboot.service;

public interface AdminService {

}
